<?php  
  
include 'connection.php';
  
$setSql = "SELECT * FROM `speedway`";  
$setRec = mysqli_query($link, $setSql);  
  
$columnHeader = '';  
$columnHeader = "id" . "\t". "Speedway_No" . "\t" . "Date" . "\t" . "Origin" . "\t" . "Country" . "\t" . "Destination" . "\t" . "From_Name". "\t" . "From_Address" . "\t" . "From_Address2" . "\t" . "From_Number" . "\t" . "To_Name" . "\t" . "To_Address" . "\t" . "To_Address2" . "\t" . "To_Address3" . "\t" . "To_Address4" . "\t" . "To_Number" . "\t" . "To_Number2". "\t" . "Service". "\t" . "Counter_Part". "\t" . "Weight". "\t" . "CPK". "\t" . "OC". "\t" . "Customer_Fee". "\t" . "Service_Fee". "\t" . "PR". "\t" . "Tracking_Number". "\t" . "Tracking_Website". "\t" . "Link". "\t" . "Status". "\t" . "Payment". "\t" . "Remarks" ;  
  
$setData = '';  
  
while ($rec = mysqli_fetch_row($setRec)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=User_Detail_Reoprt.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  
  
echo ucwords($columnHeader) . "\n" . $setData . "\n";  

?>  