<?php
session_start();
if(isset($_SESSION['Role'])) {
    if (time() - $_SESSION['timestamp'] > 600){
    header('Location: logout.php');
    }
  else{
    $_SESSION['timestamp'] = time();
  }
  }
  else{
    header('Location: login.php');
  }
?>

<!doctype html>
<html lang="en">
  <head>
    <title>Fee Update</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<!-- jQuery -->
<script type="text/javascript" src="dist/jquery.tabledit.js"></script>
  </head>
  <body>
  <div class="container">
  <a href="Admin_Dashboard.php"> < Back to Home</a>
  <p class="h3" style="color:blue;">Service Fee Update</p>
  <table id="data_table" class="table table-striped">
<thead>
<tr>
<th>Id</th>
<th>Speedway No</th>
<th>Customer Fee</th>
<th>Service Fee</th>

</tr>
</thead>
<tbody>
<?php
include 'connection.php';
$sql_query = "SELECT id, Speedway_No, Customer_Fee, Service_Fee FROM speedway WHERE Service_Fee = '0'";
$resultset = mysqli_query($link, $sql_query) or die("database error:". mysqli_error($conn));
while( $developer = mysqli_fetch_assoc($resultset) ) {
?>
<tr id="<?php echo $developer ['id']; ?>">
<td><?php echo $developer ['id']; ?></td>
<td><?php echo $developer ['Speedway_No']; ?></td>
<td><?php echo $developer ['Customer_Fee']; ?></td>
<td><?php echo $developer ['Service_Fee']; ?></td>


</tr>
<?php } ?>
</tbody>
</table>

</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
   
    <script type="text/javascript" src="custom_table_edit.js"></script>
  </body>
</html>