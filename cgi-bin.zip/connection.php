<?php

$link = mysqli_connect("localhost", "speedway1", "speedway1", "hhh");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>