
function search() {

  $.ajax({
    type: "POST",
    url: "fetchintextbox.php",
    data: { id: $("#id").val() },
    dataType: "json",
    beforeSend: function (e) {
      if (e && e.overrideMimeType) {
        e.overrideMimeType("application/json;charset=UTF-8");
      }
    },
    success: function (response) {
      //$("#loading").hide(); 

      if (response.status == "success") {
        $("#Date").val(response.Date);
        $("#Country").val(response.Country);
        $("#Destination").val(response.Destination);
        $("#From_Name").val(response.From_Name);
        $("#From_Address").val(response.From_Address);
        $("#From_Address2").val(response.From_Address2);
        $("#From_Number").val(response.From_Number);
        $("#To_Name").val(response.To_Name);
        $("#To_Address").val(response.To_Address);
        $("#To_Address2").val(response.To_Address2);
        $("#To_Address3").val(response.To_Address3);
        $("#To_Address4").val(response.To_Address4);
        $("#To_Number").val(response.To_Number);
        $("#To_Number2").val(response.To_Number2);
        $("#Service").val(response.Service);
        $("#Counter_Part").val(response.Counter_Part);
        $("#Weight").val(response.Weight);
        $("#CPK").val(response.CPK);
        $("#OC").val(response.OC);
        $("#Customer_Fee").val(response.Customer_Fee);
        $("#Tracking_Number").val(response.Tracking_Number);
        $("#Tracking_Website").val(response.Tracking_Website);
        $("#Link").val(response.Link);
        $("#Status").val(response.Status);
        $("#Payment").val(response.Payment);
        $("#Remarks").val(response.Remarks);
       
      } else {
        alert("Speedway No Does Not Exist.");
      }
    },
    error: function (xhr, ajaxOptions, thrownError) {
      alert(xhr.responseText);
    }
  });
}

$(document).ready(function () {
  //$("#loading").hide(); // Hide loading

  $("#btn_search").click(function () { // When the user clicks the Search button
    search(); // Call search function 
  });

  $("#id").keyup(function () { // When the user presses a key on the keyboard
    if (event.keyCode == 13) { // If user press ENTER key
      search(); // Call  search function 
    }
  });
});
