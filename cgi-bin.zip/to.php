<!DOCTYPE html>
<html lang="en">
<head>
<LINK REL="SHORTCUT ICON"
       HREF="sclogo.png">

<style>
input, select {
    width: 50%;
    padding: 12px 20px;
    margin: 5px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
body {
padding-left:80px;
background-color:#f2f2f2;
font-family:'arial',sans-serif;}
</style>

<meta charset="UTF-8">
<title>Update Form</title>
</head>
<body>
<img src="s2.jpg" height=100px; width=500px;>
<br />
<br />
<h2> To Name Form </h2>
<form action="addto.php" method="post">


<input type="number" name="speedway" placeholder="Enter Speedway No">
<br />
<input type="text" name="toname" placeholder="Enter Name">
<br />

<input type="submit" value="Submit">

</form>


</body>
</html>