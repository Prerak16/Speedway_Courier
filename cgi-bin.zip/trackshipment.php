<!doctype html>
<html lang="en">

<head>
    <title>Track Shipment</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <LINK REL="SHORTCUT ICON"
       HREF="sclogo.png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
        crossorigin="anonymous">
    <link href="style.css" rel="stylesheet" type="text/css" />
    <link href="nav.css" rel="stylesheet" type="text/css"/>
    <link href="https://cdn.rawgit.com/michalsnik/aos/2.1.1/dist/aos.css" rel="stylesheet">
    <link href="animate.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        footer {
            background-color: #0F181F;
            color: #8A8A8C;
            padding-top: 40px;

        }

        .foothead {
            color: white;
            font-size: 25px;
        }

        ul {
            list-style-type: none;
            padding-left: 0px;

        }

        .line {
            width: 50px;
            height: 5px;
            background-color: #E4322B;
            margin-top: 6px;
        }

        li>a {
            text-decoration: none;
            color: #8A8A8C;
        }

        li>a:hover {
            text-decoration: none;
            color: #E4322B;
        }

        .smedia {
            margin-right: 8px;
            padding: 8px;
            border: 4px solid #8A8A8C;
            color: white;
        }

        .smedia:hover {
            border: 4px solid #E4322B;
        }
        </style>
</head>

<body>
    <!--Header Start-->
    <nav class="navbar navbar-expand-lg navbar-light">
        <a href="index.php" class="navbar-brand">
            <img src="images/logo.jpg" name="Speedway" class="img-fluid" alt="Logo" style="width:250px; height:70px;" />
        </a>
        <button class="navbar-toggler" data-toggle="collapse" data-target="#menu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="menu">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a href="index.php" class="nav-link link" style="color:black;">Home</a>
                </li>
                <li class="nav-item">
                    <a href="about.html" class="nav-link link" style="color:black;">About Us</a>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle link" style="color:black;" href="#" id="navbardrop" data-toggle="dropdown">
                        Services
                    </a>
                    <div class="dropdown-menu item animated fadeInUp">
                        <a class="dropdown-item" href="door.html">Door To Door Delivery</a>
                        <a class="dropdown-item" href="air.html">Air Freight</a>
                        <a class="dropdown-item" href="comm.html">Commerical Shipment</a>
                        <a class="dropdown-item" href="sea.html">Sea Freight</a>
                    </div>
                </li>
                <li class="nav-item">
                    <a href="track.html" class="nav-link link" style="color:black;">Track Your Shipment</a>
                </li>
                <li class="nav-item">
                    <a href="prohibited.html" class="nav-link link" style="color:black;">Prohibited Goods</a>
                </li>
                <li class="nav-item">
                    <a href="contact.html" class="nav-link link" style="color:black;">Contact Us</a>
                </li>
            </ul>
        </div>

    </nav>
    <!--Header End-->
    <hr style="height:3px;border:none;color:#333;background-color:#E4322B;margin-bottom:0px;margin-top:0px;" />
    <!--image Start-->
    <img src="images/track.png" style="object-fit:contain;" alt="Image" width="100%" height="400px" />
    <!--image End-->

        <p class="display-4 headline" style="font-size: 40px;" data-aos="fade-up" data-aos-duration="900" data-aos-anchor-placement="top-bottom">Shipment Status</p>
        <hr style="height:4px;border:none;color:#333;background-color:#E4322B;margin-bottom:0px;width:80px;" />
        <br/>
        
        <?php
        include 'checktracking.php';
        ?>
        


    <!--Footer End-->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>


    <script src="https://cdn.rawgit.com/michalsnik/aos/2.1.1/dist/aos.js"></script>
    <script type="text/javascript">
        AOS.init();
    </script>
    <script>
        function includeHTML() {
            var z, i, elmnt, file, xhttp;
            /*loop through a collection of all HTML elements:*/
            z = document.getElementsByTagName("*");
            for (i = 0; i < z.length; i++) {
                elmnt = z[i];
                /*search for elements with a certain atrribute:*/
                file = elmnt.getAttribute("w3-include-html");
                if (file) {
                    /*make an HTTP request using the attribute value as the file name:*/
                    xhttp = new XMLHttpRequest();
                    xhttp.onreadystatechange = function () {
                        if (this.readyState == 4) {
                            if (this.status == 200) { elmnt.innerHTML = this.responseText; }
                            if (this.status == 404) { elmnt.innerHTML = "Page not found."; }
                            /*remove the attribute, and call this function once more:*/
                            elmnt.removeAttribute("w3-include-html");
                            includeHTML();
                        }
                    }
                    xhttp.open("GET", file, true);
                    xhttp.send();
                    /*exit the function:*/
                    return;
                }
            }
        };
    </script>
    <script>
        includeHTML();

        var varFromPhp = null;


    </script>
</body>

</html>