<!doctype html>
<html lang="en">
<head>
<LINK REL="SHORTCUT ICON"
       HREF="sclogo.png">

<title>
	Speedway 
</title>


<meta charset="utf-8" />
<link href="data.css" rel="stylesheet" type="text/css" />
</head>

<form action="#" method="get" id="packageForm" >
<br />
<select name="choice">
<option value="one">shipment data</option>
<option value="two">payment data</option>
</select>

<input id="submitButton" type="submit" value="Submit" />

</form>
<br />
<div class="container">
 <input type="text" class="form-control" placeholder="Search Here" id="search_field"> 


<br />
<br />

<?php
session_start();


	if (!isset($_SESSION['sid']))
{
	header("location: login.php");
}
?>

<?php

include "connection.php";


$counter = $_GET['choice'];



if ($counter == 'one')
{
	
	echo '<strong> Shipment Data </strong>';
	echo '<br />';
	
	$sql="SELECT sum(service_fee) as total FROM account WHERE counter_part='star panth'";

$result = mysqli_query($link,$sql);

while ($row = mysqli_fetch_assoc($result))
{ 
   echo 'Total Amount :' .$row['total'] . ' Rs.';
}

echo '<br />';
echo '<br />';

$sql = "SELECT speedway_no,date,counter_part,service_name,destination,service_fee FROM account WHERE counter_part='star panth' and service_fee!='0'";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
		echo "<div class=\"row\">";
    echo "<div class=\"col-md-6\">";
        echo "<table id=\"myTable\" class=\"table table-inverse\" border=\"1\" cellpadding=\"20\" cellspacing=\"20\">";
            echo "<tr class=\"myHead\">";
                echo "<th bgcolor=\"#BFBFBF\">Speedway No</th>";
                echo "<th bgcolor=\"#BFBFBF\">Date</th>";
                echo "<th bgcolor=\"#BFBFBF\">Counter Part</th>";
				echo "<th bgcolor=\"#BFBFBF\">Service Name</th>";
                echo "<th bgcolor=\"#BFBFBF\">Destination</th>";
				echo "<th bgcolor=\"#BFBFBF\">Service Fee</th>";
		echo "</tr>";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                echo "<td>" ."<font color=\"#2A4D94\">" . $row['speedway_no'] ."</font>" . "</td>";
                echo "<td>" . $row['date'] . "</td>";
                echo "<td>" . $row['counter_part'] . "</td>";
				echo "<td>" . $row['service_name'] . "</td>";
				echo "<td>" . $row['destination'] . "</td>";
				echo "<td>" . $row['service_fee'] . "</td>";
			echo "</tr>";
        }
        echo "</table>";
		 echo "</div>";
		 echo "</div>";
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records were found.";
    }
} 
}
else{
	
	echo '<strong> Payment Data </strong>';
	echo '<br />';
	
	$sql="SELECT sum(rs) as total FROM account WHERE counter_part='star panth'";

$result = mysqli_query($link,$sql);

while ($row = mysqli_fetch_assoc($result))
{ 
  echo 'Total Amount :' .$row['total'] . ' Rs.';
}

echo '<br />';
echo '<br />';

$sql = "SELECT pdate,rs,counter_part,name FROM account WHERE counter_part='star panth'  and rs!='0'";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
		echo "<div class=\"row\">";
    echo "<div class=\"col-md-6\">";
        echo "<table id=\"myTable\" class=\"table table-inverse\" border=\"1\" cellpadding=\"20\" cellspacing=\"20\">";
            echo "<tr class=\"myHead\">";
                
                echo "<th bgcolor=\"#BFBFBF\">Date</th>";
				echo "<th bgcolor=\"#BFBFBF\">Rupees</th>";
                echo "<th bgcolor=\"#BFBFBF\">Counter Part</th>";
                echo "<th bgcolor=\"#BFBFBF\">Name</th>";
		echo "</tr>";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                
                echo "<td>" . $row['date'] . "</td>";
				echo "<td>" . $row['rs'] . "</td>";
                echo "<td>" . $row['counter_part'] . "</td>";
				echo "<td>" . $row['name'] . "</td>";
			echo "</tr>";
        }
        echo "</table>";
		 echo "</div>";
		 echo "</div>";
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records were found.";
    }
} 


}
// close connection
mysqli_close($link);

?>
<script src='https://code.jquery.com/jquery-1.12.4.min.js'></script>

        <script src="data.js"></script>
		

</div>
</html>